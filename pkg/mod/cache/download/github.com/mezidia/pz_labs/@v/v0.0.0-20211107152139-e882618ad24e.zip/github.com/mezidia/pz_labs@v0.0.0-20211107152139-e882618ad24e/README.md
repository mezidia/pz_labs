# pz_labs
Labs for university.
## Lab2 ##
Приклади збірки:  
- [успішна](https://github.com/mezidia/pz_labs/actions/runs/1354785465)
- [не успішна](https://github.com/mezidia/pz_labs/actions/runs/1354781931)
- [на пул реквест](https://github.com/mezidia/pz_labs/actions/runs/1354809414)
