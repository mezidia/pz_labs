package dto

type User struct {
	Name      string
	Mail 			string
	Password  string
	Interests string
}
